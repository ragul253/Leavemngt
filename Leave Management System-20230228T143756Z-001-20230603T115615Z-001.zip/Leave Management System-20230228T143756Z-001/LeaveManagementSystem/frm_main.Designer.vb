﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_main))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tsEmployee = New System.Windows.Forms.ToolStripDropDownButton()
        Me.tsRegEmp = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsListEmp = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsLeave = New System.Windows.Forms.ToolStripDropDownButton()
        Me.tsApply = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsLeaveHistory = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsMaintenance = New System.Windows.Forms.ToolStripButton()
        Me.tsUser = New System.Windows.Forms.ToolStripButton()
        Me.tsReport = New System.Windows.Forms.ToolStripButton()
        Me.tstools = New System.Windows.Forms.ToolStripDropDownButton()
        Me.NotepadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MsWordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsLogin = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(34, 34)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsEmployee, Me.tsLeave, Me.tsMaintenance, Me.tsUser, Me.tsReport, Me.tstools, Me.tsLogin})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 729)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Padding = New System.Windows.Forms.Padding(0, 0, 3, 0)
        Me.ToolStrip1.Size = New System.Drawing.Size(1464, 43)
        Me.ToolStrip1.TabIndex = 0
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1464, 51)
        Me.Panel1.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(31, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label1.Size = New System.Drawing.Size(429, 29)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "EMPLOYEE LEAVE MANAGEMENT"
        '
        'tsEmployee
        '
        Me.tsEmployee.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsRegEmp, Me.tsListEmp})
        Me.tsEmployee.Image = CType(resources.GetObject("tsEmployee.Image"), System.Drawing.Image)
        Me.tsEmployee.ImageTransparentColor = System.Drawing.Color.White
        Me.tsEmployee.Name = "tsEmployee"
        Me.tsEmployee.Size = New System.Drawing.Size(150, 38)
        Me.tsEmployee.Text = "Employees"
        '
        'tsRegEmp
        '
        Me.tsRegEmp.Image = CType(resources.GetObject("tsRegEmp.Image"), System.Drawing.Image)
        Me.tsRegEmp.Name = "tsRegEmp"
        Me.tsRegEmp.Size = New System.Drawing.Size(310, 44)
        Me.tsRegEmp.Text = "Register New Employee"
        '
        'tsListEmp
        '
        Me.tsListEmp.Image = CType(resources.GetObject("tsListEmp.Image"), System.Drawing.Image)
        Me.tsListEmp.Name = "tsListEmp"
        Me.tsListEmp.Size = New System.Drawing.Size(310, 44)
        Me.tsListEmp.Text = "List of Employee's"
        '
        'tsLeave
        '
        Me.tsLeave.BackColor = System.Drawing.SystemColors.Control
        Me.tsLeave.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsApply, Me.tsLeaveHistory})
        Me.tsLeave.Image = CType(resources.GetObject("tsLeave.Image"), System.Drawing.Image)
        Me.tsLeave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsLeave.Name = "tsLeave"
        Me.tsLeave.Size = New System.Drawing.Size(202, 38)
        Me.tsLeave.Text = "Leave of Absence"
        '
        'tsApply
        '
        Me.tsApply.Image = CType(resources.GetObject("tsApply.Image"), System.Drawing.Image)
        Me.tsApply.Name = "tsApply"
        Me.tsApply.Size = New System.Drawing.Size(314, 44)
        Me.tsApply.Text = "Apply Leave of Absence"
        '
        'tsLeaveHistory
        '
        Me.tsLeaveHistory.Image = CType(resources.GetObject("tsLeaveHistory.Image"), System.Drawing.Image)
        Me.tsLeaveHistory.Name = "tsLeaveHistory"
        Me.tsLeaveHistory.Size = New System.Drawing.Size(314, 44)
        Me.tsLeaveHistory.Text = "History"
        '
        'tsMaintenance
        '
        Me.tsMaintenance.Image = CType(resources.GetObject("tsMaintenance.Image"), System.Drawing.Image)
        Me.tsMaintenance.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsMaintenance.Name = "tsMaintenance"
        Me.tsMaintenance.Size = New System.Drawing.Size(150, 38)
        Me.tsMaintenance.Text = "Maintenance"
        '
        'tsUser
        '
        Me.tsUser.Image = CType(resources.GetObject("tsUser.Image"), System.Drawing.Image)
        Me.tsUser.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsUser.Name = "tsUser"
        Me.tsUser.Size = New System.Drawing.Size(154, 38)
        Me.tsUser.Text = "Manage User"
        '
        'tsReport
        '
        Me.tsReport.Image = CType(resources.GetObject("tsReport.Image"), System.Drawing.Image)
        Me.tsReport.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsReport.Name = "tsReport"
        Me.tsReport.Size = New System.Drawing.Size(111, 38)
        Me.tsReport.Text = "Reports"
        '
        'tstools
        '
        Me.tstools.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NotepadToolStripMenuItem, Me.MsWordToolStripMenuItem, Me.CalculatorToolStripMenuItem})
        Me.tstools.Image = CType(resources.GetObject("tstools.Image"), System.Drawing.Image)
        Me.tstools.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tstools.Name = "tstools"
        Me.tstools.Size = New System.Drawing.Size(105, 38)
        Me.tstools.Text = "Tools"
        '
        'NotepadToolStripMenuItem
        '
        Me.NotepadToolStripMenuItem.Image = CType(resources.GetObject("NotepadToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NotepadToolStripMenuItem.Name = "NotepadToolStripMenuItem"
        Me.NotepadToolStripMenuItem.Size = New System.Drawing.Size(202, 44)
        Me.NotepadToolStripMenuItem.Text = "Notepad"
        '
        'MsWordToolStripMenuItem
        '
        Me.MsWordToolStripMenuItem.Image = CType(resources.GetObject("MsWordToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MsWordToolStripMenuItem.Name = "MsWordToolStripMenuItem"
        Me.MsWordToolStripMenuItem.Size = New System.Drawing.Size(202, 44)
        Me.MsWordToolStripMenuItem.Text = "Ms Word"
        '
        'CalculatorToolStripMenuItem
        '
        Me.CalculatorToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.CalculatorToolStripMenuItem.Image = CType(resources.GetObject("CalculatorToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CalculatorToolStripMenuItem.Name = "CalculatorToolStripMenuItem"
        Me.CalculatorToolStripMenuItem.Size = New System.Drawing.Size(202, 44)
        Me.CalculatorToolStripMenuItem.Text = "Calculator"
        '
        'tsLogin
        '
        Me.tsLogin.Image = CType(resources.GetObject("tsLogin.Image"), System.Drawing.Image)
        Me.tsLogin.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsLogin.Name = "tsLogin"
        Me.tsLogin.Size = New System.Drawing.Size(94, 38)
        Me.tsLogin.Text = "Login"
        '
        'Form1
        '
        Me.AllowDrop = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1464, 772)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.IsMdiContainer = True
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents tsMaintenance As ToolStripButton
    Friend WithEvents tsUser As ToolStripButton
    Friend WithEvents tsReport As ToolStripButton
    Friend WithEvents tsLogin As ToolStripButton
    Friend WithEvents tsLeave As ToolStripDropDownButton
    Friend WithEvents tsApply As ToolStripMenuItem
    Friend WithEvents tsLeaveHistory As ToolStripMenuItem
    Friend WithEvents tsEmployee As ToolStripDropDownButton
    Friend WithEvents tsRegEmp As ToolStripMenuItem
    Friend WithEvents tsListEmp As ToolStripMenuItem
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents tstools As ToolStripDropDownButton
    Friend WithEvents CalculatorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NotepadToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MsWordToolStripMenuItem As ToolStripMenuItem
End Class
