﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Settings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnpositionload = New System.Windows.Forms.Button()
        Me.dtglistposition = New System.Windows.Forms.DataGridView()
        Me.npositiondelete = New System.Windows.Forms.Button()
        Me.npositionupdate = New System.Windows.Forms.Button()
        Me.npositionsave = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtposition = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btndeptLoad = New System.Windows.Forms.Button()
        Me.dtgdeptlist = New System.Windows.Forms.DataGridView()
        Me.txtdepartment = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btndeptDelete = New System.Windows.Forms.Button()
        Me.btndeptUpdate = New System.Windows.Forms.Button()
        Me.btndeptSave = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dtglistposition, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.dtgdeptlist, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.btnpositionload)
        Me.GroupBox1.Controls.Add(Me.dtglistposition)
        Me.GroupBox1.Controls.Add(Me.npositiondelete)
        Me.GroupBox1.Controls.Add(Me.npositionupdate)
        Me.GroupBox1.Controls.Add(Me.npositionsave)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtposition)
        Me.GroupBox1.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(18, 20)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.GroupBox1.Size = New System.Drawing.Size(477, 552)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Position of the Employee"
        '
        'btnpositionload
        '
        Me.btnpositionload.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnpositionload.FlatAppearance.BorderSize = 0
        Me.btnpositionload.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpositionload.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpositionload.Location = New System.Drawing.Point(356, 168)
        Me.btnpositionload.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.btnpositionload.Name = "btnpositionload"
        Me.btnpositionload.Size = New System.Drawing.Size(112, 62)
        Me.btnpositionload.TabIndex = 6
        Me.btnpositionload.Text = "Load"
        Me.btnpositionload.UseVisualStyleBackColor = False
        '
        'dtglistposition
        '
        Me.dtglistposition.AllowUserToAddRows = False
        Me.dtglistposition.AllowUserToDeleteRows = False
        Me.dtglistposition.AllowUserToResizeColumns = False
        Me.dtglistposition.AllowUserToResizeRows = False
        Me.dtglistposition.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dtglistposition.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dtglistposition.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.dtglistposition.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtglistposition.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dtglistposition.Location = New System.Drawing.Point(9, 94)
        Me.dtglistposition.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.dtglistposition.Name = "dtglistposition"
        Me.dtglistposition.RowHeadersWidth = 62
        Me.dtglistposition.Size = New System.Drawing.Size(338, 446)
        Me.dtglistposition.TabIndex = 1
        '
        'npositiondelete
        '
        Me.npositiondelete.BackColor = System.Drawing.Color.Red
        Me.npositiondelete.FlatAppearance.BorderSize = 0
        Me.npositiondelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.npositiondelete.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.npositiondelete.Location = New System.Drawing.Point(356, 315)
        Me.npositiondelete.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.npositiondelete.Name = "npositiondelete"
        Me.npositiondelete.Size = New System.Drawing.Size(112, 62)
        Me.npositiondelete.TabIndex = 5
        Me.npositiondelete.Text = "Delete"
        Me.npositiondelete.UseVisualStyleBackColor = False
        '
        'npositionupdate
        '
        Me.npositionupdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.npositionupdate.FlatAppearance.BorderSize = 0
        Me.npositionupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.npositionupdate.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.npositionupdate.Location = New System.Drawing.Point(356, 242)
        Me.npositionupdate.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.npositionupdate.Name = "npositionupdate"
        Me.npositionupdate.Size = New System.Drawing.Size(112, 62)
        Me.npositionupdate.TabIndex = 4
        Me.npositionupdate.Text = "Update"
        Me.npositionupdate.UseVisualStyleBackColor = False
        '
        'npositionsave
        '
        Me.npositionsave.BackColor = System.Drawing.Color.Lime
        Me.npositionsave.FlatAppearance.BorderSize = 0
        Me.npositionsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.npositionsave.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.npositionsave.ForeColor = System.Drawing.Color.White
        Me.npositionsave.Location = New System.Drawing.Point(356, 94)
        Me.npositionsave.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.npositionsave.Name = "npositionsave"
        Me.npositionsave.Size = New System.Drawing.Size(112, 62)
        Me.npositionsave.TabIndex = 3
        Me.npositionsave.Text = "Save"
        Me.npositionsave.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 46)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 24)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Position :"
        '
        'txtposition
        '
        Me.txtposition.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtposition.Location = New System.Drawing.Point(118, 42)
        Me.txtposition.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.txtposition.Multiline = True
        Me.txtposition.Name = "txtposition"
        Me.txtposition.Size = New System.Drawing.Size(348, 38)
        Me.txtposition.TabIndex = 2
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.btndeptLoad)
        Me.GroupBox2.Controls.Add(Me.dtgdeptlist)
        Me.GroupBox2.Controls.Add(Me.txtdepartment)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.btndeptDelete)
        Me.GroupBox2.Controls.Add(Me.btndeptUpdate)
        Me.GroupBox2.Controls.Add(Me.btndeptSave)
        Me.GroupBox2.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(519, 20)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.GroupBox2.Size = New System.Drawing.Size(510, 552)
        Me.GroupBox2.TabIndex = 9
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Department of the Employee"
        '
        'btndeptLoad
        '
        Me.btndeptLoad.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btndeptLoad.FlatAppearance.BorderSize = 0
        Me.btndeptLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndeptLoad.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndeptLoad.Location = New System.Drawing.Point(388, 168)
        Me.btndeptLoad.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.btndeptLoad.Name = "btndeptLoad"
        Me.btndeptLoad.Size = New System.Drawing.Size(112, 62)
        Me.btndeptLoad.TabIndex = 6
        Me.btndeptLoad.Text = "Load"
        Me.btndeptLoad.UseVisualStyleBackColor = False
        '
        'dtgdeptlist
        '
        Me.dtgdeptlist.AllowUserToAddRows = False
        Me.dtgdeptlist.AllowUserToDeleteRows = False
        Me.dtgdeptlist.AllowUserToResizeColumns = False
        Me.dtgdeptlist.AllowUserToResizeRows = False
        Me.dtgdeptlist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dtgdeptlist.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dtgdeptlist.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.dtgdeptlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgdeptlist.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dtgdeptlist.Location = New System.Drawing.Point(9, 94)
        Me.dtgdeptlist.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.dtgdeptlist.Name = "dtgdeptlist"
        Me.dtgdeptlist.RowHeadersWidth = 62
        Me.dtgdeptlist.Size = New System.Drawing.Size(370, 446)
        Me.dtgdeptlist.TabIndex = 1
        '
        'txtdepartment
        '
        Me.txtdepartment.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdepartment.Location = New System.Drawing.Point(171, 42)
        Me.txtdepartment.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.txtdepartment.Multiline = True
        Me.txtdepartment.Name = "txtdepartment"
        Me.txtdepartment.Size = New System.Drawing.Size(314, 38)
        Me.txtdepartment.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(27, 46)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(133, 24)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Department :"
        '
        'btndeptDelete
        '
        Me.btndeptDelete.BackColor = System.Drawing.Color.Red
        Me.btndeptDelete.FlatAppearance.BorderSize = 0
        Me.btndeptDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndeptDelete.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndeptDelete.Location = New System.Drawing.Point(388, 315)
        Me.btndeptDelete.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.btndeptDelete.Name = "btndeptDelete"
        Me.btndeptDelete.Size = New System.Drawing.Size(112, 62)
        Me.btndeptDelete.TabIndex = 5
        Me.btndeptDelete.Text = "Delete"
        Me.btndeptDelete.UseVisualStyleBackColor = False
        '
        'btndeptUpdate
        '
        Me.btndeptUpdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btndeptUpdate.FlatAppearance.BorderSize = 0
        Me.btndeptUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndeptUpdate.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndeptUpdate.Location = New System.Drawing.Point(388, 242)
        Me.btndeptUpdate.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.btndeptUpdate.Name = "btndeptUpdate"
        Me.btndeptUpdate.Size = New System.Drawing.Size(112, 62)
        Me.btndeptUpdate.TabIndex = 4
        Me.btndeptUpdate.Text = "Update"
        Me.btndeptUpdate.UseVisualStyleBackColor = False
        '
        'btndeptSave
        '
        Me.btndeptSave.BackColor = System.Drawing.Color.Lime
        Me.btndeptSave.FlatAppearance.BorderSize = 0
        Me.btndeptSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndeptSave.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndeptSave.Location = New System.Drawing.Point(388, 94)
        Me.btndeptSave.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.btndeptSave.Name = "btndeptSave"
        Me.btndeptSave.Size = New System.Drawing.Size(112, 62)
        Me.btndeptSave.TabIndex = 3
        Me.btndeptSave.Text = "Save"
        Me.btndeptSave.UseVisualStyleBackColor = False
        '
        'frm_Settings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1047, 602)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frm_Settings"
        Me.Text = "Settings"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.dtglistposition, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.dtgdeptlist, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnpositionload As Button
    Friend WithEvents dtglistposition As DataGridView
    Friend WithEvents npositiondelete As Button
    Friend WithEvents npositionupdate As Button
    Friend WithEvents npositionsave As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txtposition As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btndeptLoad As Button
    Friend WithEvents dtgdeptlist As DataGridView
    Friend WithEvents btndeptDelete As Button
    Friend WithEvents btndeptUpdate As Button
    Friend WithEvents btndeptSave As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents txtdepartment As TextBox
End Class
